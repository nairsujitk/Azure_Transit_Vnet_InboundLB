#!/bin/bash

apt-get update
apt-get install apache2
cat /var/www/html/index.html >> index.html.old
echo -e "\n\n\n\n\n\n\n\t\t\t\t\t\t\t/WEBSERVER-\t1" > /var/www/html/index.html
